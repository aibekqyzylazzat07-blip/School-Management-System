import mysql.connector
from rich.table import Table
from rich.console import Console
from rich import box

# simple Student class (for OOP requirement)
class Student:
    def __init__(self, student_id, name):
        self.student_id = student_id
        self.name = name


console = Console()

# this function connects to the MySQL database
def connect():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="school_db"
    )


# ===================== STUDENTS =====================

# add a new student
def add_student():
    try:
        conn = connect()
        cursor = conn.cursor()

        sid = input("Student ID: ")
        # validate input (ID must be number)
        if not sid.isdigit():
            print("Invalid ID! Must be a number.")
            return
        name = input("Student Name: ")
        student = Student(sid, name)

        # check if student already exists
        cursor.execute("SELECT * FROM students WHERE student_id=%s", (sid,))
        if cursor.fetchone():
            print("Student already exists!")
        else:
            cursor.execute(
                "INSERT INTO students (student_id, name) VALUES (%s, %s)",
                (student.student_id, student.name)
            )
            conn.commit()
            print("Student added!")

        conn.close()

    except Exception as e:
        print("Error:", e)


# display all students (sorted by name)
def view_students():
    conn = connect()
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM students ORDER BY name ASC")

    table = Table(title="Students")
    table.add_column("ID", style="cyan")
    table.add_column("Name", style="green")

    for row in cursor.fetchall():
        table.add_row(str(row[0]), row[1])

    console.print(table)
    conn.close()


# delete student by ID
def delete_student():
    conn = connect()
    cursor = conn.cursor()

    sid = input("Enter ID to delete: ")

    cursor.execute("DELETE FROM students WHERE student_id=%s", (sid,))
    conn.commit()

    print("Deleted!")
    conn.close()


# update student name
def update_student():
    conn = connect()
    cursor = conn.cursor()

    sid = input("Enter ID: ")
    name = input("New Name: ")

    cursor.execute(
        "UPDATE students SET name=%s WHERE student_id=%s",
        (name, sid)
    )

    conn.commit()
    print("Updated!")
    conn.close()


# search student by name
def search_student():
    conn = connect()
    cursor = conn.cursor()

    name = input("Search name: ")

    cursor.execute(
        "SELECT * FROM students WHERE name LIKE %s",
        ('%' + name + '%',)
    )

    table = Table(title="Search Results")
    table.add_column("ID", style="cyan")
    table.add_column("Name", style="green")

    for row in cursor.fetchall():
        table.add_row(str(row[0]), row[1])

    console.print(table)
    conn.close()


# ===================== TEACHERS =====================

# add a new teacher
def add_teacher():
    try:
        conn = connect()
        cursor = conn.cursor()

        tid = input("Teacher ID: ")
        if not tid.isdigit():
            print("Invalid ID!")
            return
        name = input("Teacher Name: ")

        cursor.execute(
            "INSERT INTO teachers (teacher_id, name) VALUES (%s, %s)",
            (tid, name)
        )

        conn.commit()
        print("Teacher added!")
        conn.close()

    except Exception as e:
        print("Error:", e)


# display all teachers
def view_teachers():
    conn = connect()
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM teachers")

    table = Table(title="Teachers")
    table.add_column("ID", style="cyan")
    table.add_column("Name", style="green")

    for row in cursor.fetchall():
        table.add_row(str(row[0]), row[1])

    console.print(table)
    conn.close()

# delete teacher by ID
def delete_teacher():
    try:
        conn = connect()
        cursor = conn.cursor()

        tid = input("Enter teacher ID to delete: ")

        cursor.execute(
            "DELETE FROM teachers WHERE teacher_id=%s",
            (tid,)
        )

        conn.commit()
        print("Teacher deleted!")
        conn.close()

    except Exception as e:
        print("Error:", e)

# update teacher name
def update_teacher():
    try:
        conn = connect()
        cursor = conn.cursor()

        tid = input("Enter teacher ID: ")
        new_name = input("Enter new name: ")

        cursor.execute(
            "UPDATE teachers SET name=%s WHERE teacher_id=%s",
            (new_name, tid)
        )

        conn.commit()
        print("Teacher updated!")
        conn.close()

    except Exception as e:
        print("Error:", e)


# ===================== COURSES =====================

# add a new course
def add_course():
    conn = connect()
    cursor = conn.cursor()

    cid = input("Course ID: ")
    if not cid.isdigit():
        print("Invalid ID!")
        return
    name = input("Course Name: ")

    cursor.execute(
        "INSERT INTO courses (course_id, course_name) VALUES (%s, %s)",
        (cid, name)
    )

    conn.commit()
    print("Course added!")
    conn.close()


# display all courses
def view_courses():
    conn = connect()
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM courses")

    table = Table(title="Courses")
    table.add_column("ID", style="cyan")
    table.add_column("Course Name", style="green")

    for row in cursor.fetchall():
        table.add_row(str(row[0]), row[1])

    console.print(table)
    conn.close()


# ===================== REGISTRATION =====================

# register student to a course
def register_student():
    try:
        conn = connect()
        cursor = conn.cursor()

        sid = input("Student ID: ")
        cid = input("Course ID: ")

        cursor.execute(
            "INSERT INTO registrations (student_id, course_id) VALUES (%s, %s)",
            (sid, cid)
        )

        conn.commit()
        print("Student registered!")
        conn.close()

    except Exception as e:
        print("Error:", e)
from rich import box

# show registrations with names
def view_registrations():
    conn = connect()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT students.name, courses.course_name
        FROM registrations
        JOIN students ON registrations.student_id = students.student_id
        JOIN courses ON registrations.course_id = courses.course_id
    """)

    table = Table(title="Registrations", box=box.DOUBLE)
    table.add_column("Student", style="cyan")
    table.add_column("Course", style="green")

    for row in cursor.fetchall():
        table.add_row(row[0], row[1])

    console.print(table)
    conn.close()

# ===================== MENU =====================

# main menu loop
def main():
    while True:
        print("\n=== SCHOOL MANAGEMENT SYSTEM ===")
        print("1. Add student")
        print("2. View students")
        print("3. Delete student")
        print("4. Update student")
        print("5. Search student")
        print("6. Add course")
        print("7. View courses")
        print("8. Register student")
        print("9. Add teacher")
        print("10. View teachers")
        print("11. Delete teacher")
        print("12. Update teacher")
        print("13. View registrations")
        print("0. Exit")

        choice = input("Choice: ")

        if choice == "1":
            add_student()
        elif choice == "2":
            view_students()
        elif choice == "3":
            delete_student()
        elif choice == "4":
            update_student()
        elif choice == "5":
            search_student()
        elif choice == "6":
            add_course()
        elif choice == "7":
            view_courses()
        elif choice == "8":
            register_student()
        elif choice == "9":
            add_teacher()
        elif choice == "10":
            view_teachers()
        elif choice == "11":
            delete_teacher()
        elif choice == "12":
            update_teacher()
        elif choice == "13":
            view_registrations()
        elif choice == "0":
            print("Goodbye!")
            break
        else:
            print("Invalid input, try again.")


# program starts here
main()